package org.thymeleaf.dialect.springdata.decorator;

public class CompactPagerDecorator extends AbstractPagerDecorator {

    @Override
    public String getIdentifier() {
        return "compact-pager";
    }

}
