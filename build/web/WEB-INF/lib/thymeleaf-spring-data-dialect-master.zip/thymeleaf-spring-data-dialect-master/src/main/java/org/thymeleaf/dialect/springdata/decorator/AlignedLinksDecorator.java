package org.thymeleaf.dialect.springdata.decorator;

public final class AlignedLinksDecorator extends AbstractPagerDecorator {

    public String getIdentifier() {
        return "aligned-links";
    }

}
