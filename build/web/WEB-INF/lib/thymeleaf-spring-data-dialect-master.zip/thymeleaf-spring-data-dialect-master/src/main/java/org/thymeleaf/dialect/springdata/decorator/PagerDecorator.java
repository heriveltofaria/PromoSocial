package org.thymeleaf.dialect.springdata.decorator;

public class PagerDecorator extends AbstractPagerDecorator {

    public String getIdentifier() {
        return "pager";
    }

}
